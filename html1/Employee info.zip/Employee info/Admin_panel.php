<?php

    session_start();
    include("classes/connect.php");
    include('classes/employee.php');
    include('classes/admin-login.php');

    $login =new Login();
	$user_data=$login->check_login($_SESSION['admin_id']);

    $Db =new Employee();
    $data= $Db->get_employee();

    echo "<pre>";
    echo print_r($_SESSION['admin_id']);
    echo "</pre>";

    if($_SERVER['REQUEST_METHOD']== 'POST')
    {
        $Db = new Employee();
        $result=$Db->validate($_POST);
        if($result)
        print_r($result);
    }
    
    if($_GET)
    $manage_emoloyee = $_GET['manage_employee'];//the  $_GET is accesed with the key index to get the value to asign to the left variable
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin | panel</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <div class="navbar"><h2>Admin panel</h2><a href="logout-admin.php">
		<span style=" font-size:11px; float:right; margin-top: -20px; color:white;">Logout</span>
		</a></div>
    <div class="container">
        
        <div class="main">
            <div class="menu-bar">menu
             <br><br>
                <ul>
                    <li><div class="manage_employee">Manage Employee </div><br>
                        <ul>
                        <a href="admin_panel.php?manage_employee=view_table"><li class ="manage_employee_list">VIEW employee table</li></a>
                        <br>
                        <a href="admin_panel.php?manage_employee=add_employee"><li class ="manage_employee_list">ADD employee data</li></a>
                        <br>
                        <a href="admin_panel.php?manage_employee=sort"><li class ="manage_employee_list">SORT employee table</li></a>
                        <br>
                        <a href="admin_panel.php?manage_employee=remove"><li class ="manage_employee_list">Remove employee</li></a>
                        <br>
                        </ul>
                    </li>
                    <li><div class="change_site_settings">Site Settings</div></li>
                </ul>
            </div>
            <div class="content">
                <?php
                   if(isset($manage_emoloyee)) 
                   {
                        switch ($manage_emoloyee) {
                            case 'view_table':
                                # code...
                                include('table1.php');
                                break;

                            case 'add_employee':
                                # code...
                                include('add_employee.php');
                                break;

                            case 'sort':
                                # code...
                                include('table_sort.php');
                                break;

                            case 'remove':
                                # code...
                                include('remove_employee.php');
                                break;
                                        
                            default:
                                # code...
                                include('company.php');// might contain company logo as bakground or site extra details
                                break;
                        }
                   }
                ?>
            </div>
        
        </div>
    </div>
    <div class="footer"><h2>footer</h2></div>
</body>
</html>