<?php
include("classes/connect.php");
include("classes/employee.php");

   $Db =new Employee();
  $data= $Db->get_employee(); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Table</title>
    <link href="style1.css" rel="stylesheet">
</head>
<body>
    <div class="navbar"><h2>Admin panel</h2></div>
       <!--<div class="any"></div>-->
        <div class="info_table" >
            <table class="content-table">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>NAME</th>
                        <th>POSITION</th>
                        <th>TEL</th>
                        <th>SEX</th>
                        <th>SIGN</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                        if($data)
                        {
                            $i=0;
                            foreach ($data as $ROW)//$ROW is where the $data data is stored as it loops $ROW contains each row in the db one at a time as it loops
                            {
                                # code... 
                                include("table_data.php");
                            }
                        }
                    
                
                    ?>
                   
                </tbody>
            </table>
        </div>
</body>
</html>