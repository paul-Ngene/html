<?php

    class Signup
    {
        private $error ="";
        public function validate($data)
        {
            foreach ($data as $key => $value) {
                # code...
                if(empty($value))
                {
                    $this->error = $this->error . $key . " is empty!<br>";
                }
                if($key== 'first-name' || $key == 'last-name')
                {
                    if (is_numeric($value)) {
        
                        $this->error = $this->error . "first name cant be a number<br>";
                   }
   
                   if (strstr($value, " ")) {
           
                        $this->error = $this->error . "first name cant have spaces<br>";
                   }
                }
                if($key == "email")
                {
                    if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$value)) {
            
                        $this->error = $this->error . "invalid email address!<br>";
                    }
                }
            }

            if($data['password'] != $data['password1'])
            {
                $this->error= $this->error . "Password not the same<br>";
            }

            if($this->error == "")
            {
                $this->create_admin_user($data);
            }
            else
            {
                return $this->error;
            }
        }

        private function create_admin_user($data)
        {
            $admin_id = $this->create_admin_id();
            $first_name = ucfirst($data['first-name']);
            $last_name = ucfirst($data['last-name']);
            $phone = $data['tel'];
            $email = $data['email'];
            $password = $data['password'];
            $position = $data['position'];
            $name = $first_name . " " . $last_name;
            $gender = $data['gender'];

            $Db= new Database();

            $query = "insert into employee ( admin_id, Name, position, tel, gender,password) values ( '$admin_id', '$name', '$position', '$phone', '$gender','$password') ";

            $Db->save($query);
        }

        private function create_admin_id()
        {

            $length = rand(4,19);
            $number = "";
            for ($i=0; $i < $length; $i++) { 
                # code...
                $new_rand = rand(0,9);

                $number = $number . $new_rand;
            }

            return $number;
        }
    }
?>