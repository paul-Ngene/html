<?php
  class Employee
  {
    private $error ="";
    public function validate($data)
    {
      foreach ($data as $key => $value) 
      {
        # code...
        if(empty($value))
        {
          if ($key == 'tooltip') {
            # code...
            continue;
          }
          $this->error = $this->error . $key . " is empty!<br>";
        }
        if($key== 'first-name' || $key == 'last-name')
        {
            if (is_numeric($value)) {

                $this->error = $this->error . "first name cant be a number<br>";
           }

           if (strstr($value, " "))
            {
              $this->error = $this->error . "first name cant have spaces<br>";
           }
        }
        if($key == "position")
        {
          if (is_numeric($value)) {

            $this->error = $this->error . "Position cant be a number<br>";
          }

          if (strstr($value, " "))
          {
            $this->error = $this->error . "postion cant have spaces<br>";
          }
        }

        if($key == "tel")
        {
          if (!is_numeric($value)) {

            $this->error = $this->error . "Phone must be a number<br>";
          }
          if (strstr($value, " "))
          {
            $this->error = $this->error . "Phone cant have spaces<br>";
          }
        }
      }

      if($this->error == "")
      {
          $this->create_employee($data);
      }
      else
      {
          return $this->error;
      }
    }

    private function create_employee($data)
    {
      $first_name = ucfirst($data['first-name']);
      $last_name = ucfirst($data['last-name']);
      $phone = $data['phone'];
      $tooltip = $data['tooltip'];
      $position = $data['position'];
      $name = $first_name . " " . $last_name;
      $gender = $data['gender'];

      $Db= new Database();

      $query = "insert into employee ( Name, position, tel, gender,user_tooltip) values ( '$name', '$position', '$phone', '$gender','$tooltip') ";

      $Db->save($query);
    }

    public function get_employee()
    {
  
      $query = "select * from employee ";
      
      $DB = new Database();
      $result = $DB->read($query);
  
      if($result)
      {
  
        $row = $result;
        return $row;
      }else
      {
        return false;
      }
    }

  }  
?>