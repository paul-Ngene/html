<?php

    class Login
    {
        public function validate($data)
        {
            $email = $data['email'];
            $password = $data['password'];
            $Db = new Database();            
            if(!empty($email) && !empty($password))
            {
                if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)) {
            
                    echo "invalid email address<br>";
                    
                }
                else
                {
                    $query = "SELECT * from employee where email = '$email' limit 1 ";
                    $result=$Db->read($query); //this returns false if email is not registerd
                }

                if($result)
                {
                    $row = $result[0];
                    if($password == $row['password'] && $email == $row['email'])
                    {
                        $_SESSION['admin_id'] = $row['admin_id'];
                        return true;
                    }
                    else
                    {   
                        echo "<br>incorrect email or password<br>";
                        echo "Not a board member<br>";
                        //echo "<pre>";
                        //echo print_r($result);
                        //echo "</pre>";
                        
                        
                    }
                }
                else {
                    echo "<br>incorrect email or password<br>";
                        echo "Not a board member<br>";
                }
            }
            else
            echo "email or password CANNOT be Empty"; 
        }
    

        public function check_login($id)
        {
            if(is_numeric($id))
            {
                $query = "select * from employee where admin_id = '$id' limit 1 ";// selects a single row from array of rows where $id is same as user_id 
                //$query = "select user_id from users where user_id = '$id' limit 1 "; 
                // selects only the user_id from a row in the array of rows where $id is same as user_id 
                $DB= new Database();
                $result= $DB->read($query); // result is an array of rows
                
                /*echo "<pre>";
                var_dump($result);
                echo "</pre>";*/

                if($result)
                {
                    $user_data = $result[0]; //returning the first row
                    return $user_data;
                }
                else
                {
                    header("Location: admin-login.php");
                    die;
                }
                
            }
            else
            {
                header("Location: admin-login.php");
                die;
            }
        }
    }

?>