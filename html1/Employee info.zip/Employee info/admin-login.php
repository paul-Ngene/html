<?php
    session_start();
    include('classes/connect.php');
    include('classes/admin-login.php');

    $Db = new Login();

    if($_SERVER['REQUEST_METHOD'] =='POST')
    {
        $result=$Db->validate($_POST);
        if($result)
        {
            header('Location: Admin_panel.php');
            die;
        }
        
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Login</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <div class="navbar"><h2>Admin panel</h2></div>
    <div class ="signup">
        <form action="" method="post">

            <div class = "input-div">            
            <input class= "input" type="text" name = "email" placeholder = "Email">
            </div>

            <div class = "input-div">            
            <input class= "input" type="password" name = "password" placeholder = "Password">
            </div>
            
            <div class = "input-div"> 
                <input type="submit" id="submit-btn" value="Admin login">
            </div>
            
        </form>
    </div>
    
</body>
</html>