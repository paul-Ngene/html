<div class="info_table">
            <table class="content-table">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>NAME</th>
                        <th>POSITION</th>
                        <th>TEL</th>
                        <th>SEX</th>
                        <th>SIGN</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                        if($data)
                        {
                            $i=0;
                            foreach ($data as $ROW)//$ROW is where the $data data is stored as it loops $ROW contains each row in the db one at a time as it loops
                            {
                                # code... 
                                include("table_data.php");
                            }
                        }
                    
                
                    ?>
                   
                </tbody>
            </table>
        </div>