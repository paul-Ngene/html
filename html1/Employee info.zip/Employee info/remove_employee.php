<?php
   $Db =new Employee();
  $data= $Db->get_employee(); 

    if($manage_emoloyee=='remove')
    {
        if(isset($_POST['submit']))
        {
            foreach ($_POST['todelete'] as $delete_id) {
                # code...
                $Db = new  Database();
                $query= "DELETE from employee where id = $delete_id";
                $result = $Db->save($query);
            }
        }
    }
?>
<div class="remove_main">
    <div class="check_table">table here
        <div class="info_table">
            <table class="content-table">
                <thead>
                <tr>
                        <th>S/N</th>
                        <th>NAME</th>
                        <th>POSITION</th>
                        <th>TEL</th>
                        <th>SEX</th>
                        <th>SIGN</th>
                    </tr>
                </thead>
                <tbody>
                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">

                <?php
                        if($data)
                        {
                            $i=0;
                            foreach ($data as $ROW)//$ROW is where the $data data is stored as it loops $ROW contains each row in the db one at a time as it loops
                            {
                                # code... 
                                include("table_data.php");
                            }
                           
                        }
                    
                    ?>
                       <input type="submit" value="Remove"name="submit">
                       </form>
                </tbody>
            </table>
        </div>
    </div>
    <div class="search_to_remove">search
        <br>
        
    </div>
</div>