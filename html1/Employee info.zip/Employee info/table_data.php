<?php

   $name = $ROW['Name'];
   $gender = $ROW['gender'];
   $tel = $ROW['tel'];
   $position = $ROW['position'];
   $i=$i+1;

   if($_GET)
    $manage_emoloyee = $_GET['manage_employee'];

?>
<tr>
    <td class = "number"><?php echo $i ?></td>
    <td><?php echo $name?></td>
    <td><?php echo $position ?></td>
    <td><?php echo $tel ?></td>
    <td><?php echo $gender ?></td>
    <td></td>
</tr>

<?php

        
        echo '<tr>'.
        '<td><input type="checkbox" value = "\' . $data[\'id\'] . \'" name = "todelete[]"/></td>'.
        '<td class = "number"><?php echo $i ?></td>'.
        '<td><?php echo $name?></td>'.
        '<td><?php echo $position ?></td>'.
        '<td><?php echo $tel ?></td>'.
        '<td><?php echo $gender ?></td>'.
        '<td></td>'.
        '</tr>';
        
           
?>

