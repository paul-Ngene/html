<?php
    	include("classes/signup.php");
        include("classes/connect.php");

        
        if($_SERVER['REQUEST_METHOD']== 'POST')
        {
            $Db = new Signup();
            $result=$Db->validate($_POST);
            if($result)
            print_r($result);
        }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | signup</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="navbar"><h2>Admin panel</h2></div>
    <div class ="signup">
        <form action="" method="post">

            <div class = "input-div">
                <input class= "input" type="text" name = "first-name" placeholder = "First name">
            </div>  

            <div class = "input-div">
                <input class= "input" type="text" name = "last-name" placeholder = "Last name">
            </div>   

            <div class = "input-div">                 
                <input class= "input" type="text" name = "position" placeholder = "Enter position">
            </div>
           
            <div class = "input-div">                    
                <select name="gender" id ="select">
                    <option><?php echo "" ?></option>
                    <option>Male</option>
                    <option>Female</option>
                </select> 
            </div>
            
            <div class = "input-div">            
            <input class= "input" type="tel" name = "tel" placeholder = "Phone">
            </div>

            <div class = "input-div">            
            <input class= "input" type="text" name = "email" placeholder = "Email">
            </div>
            <div class = "input-div">            
            <input class= "input" type="password" name = "password" placeholder = "Password">
            </div>
            
            <div class = "input-div">            
            <input class= "input" type="password" name = "password1" placeholder = "Retype password">
            </div> 

            <div class = "input-div"> 
                <input type="submit" id="submit-btn" value="Admin signup">
            </div>
            
        </form>
    </div>
    
</body>
</html>