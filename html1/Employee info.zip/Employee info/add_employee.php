<fieldset class="field">
                    <form action="" method="post">

                        <div class = "input-div">
                             <input class= "input" type="text" name = "first-name" placeholder = "First name">
                        </div>  

                        <div class = "input-div">
                            <input class= "input" type="text" name = "last-name" placeholder = "Last name">
                        </div>   

                        <div class = "input-div">                 
                            <input class= "input" type="text" name = "position" placeholder = "Enter position">
                        </div>
                        
                        <div class = "input-div">                    
                            <select name="gender" id ="select">
                                <option>Gender</option>
                                <option>Male</option>
                                <option>Female</option>
                            </select> 
                        </div>

                        <div class = "input-div">            
                        <input class= "input" type="tel" name = "phone" placeholder = "Phone">
                        </div> 

                        <div>
                            <textarea type="text" name="tooltip" class="input-textarea" placeholder= "Anything more about our employee"></textarea>
                        </div>

                        <div> 
                            <input type="submit" id="submit-btn" value="Add Employee">
                        </div>
                        
                    </form>
                </fieldset>