<?php
	session_start();
	//unset($_SESSION['mybook_userid']);
	//$_SESSION['mybook_userid']="";
	include("classes/connect.php");
	include("classes/login.php");
	include("classes/user.php");
	include("classes/post.php");
	include("classes/image.php");


	// check if user is logged in
	$login =new Login();
	$user_data=$login->check_login($_SESSION['mybook_userid']);

	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		//echo "<pre>";
		//print_r($_POST);// $_POST contain all the text that has been posted
		//print_r($_FILES);// $_FILES contains all the file that has been posted
		//echo "</pre>";
		if(isset($_FILES['file']['tmp_name']) && $_FILES['file']['tmp_name'] != "")
		{
			//echo "<pre>";
			//print_r($_POST);// $_POST contain all the text that has been posted
			//print_r($_FILES);// $_FILES contains all the file that has been posted
			//echo "</pre>";
			//die;
			if($_FILES['file']['type']=="image/jpeg")
			{
				$allowed_size = 3*(1024*1024);
				if($_FILES['file']['size'] < $allowed_size)
				{
					// everything is fine
					$filename = "uploads/". $_FILES['file']['name'];
					move_uploaded_file($_FILES['file']['tmp_name'],$filename);

					$image= new Image();
					$image->crop_image($filename,$filename,800,800);

					if(file_exists($filename))
					{
						$userid =$user_data['user_id'];
						$query = "update users set profile_image = '$filename' where user_id ='$userid' limit 1";
						$Db= new Database();
						$Db->save($query);

						header("Location: profile.php");
						die;
					}
				}
				else
				{
					echo "<pre>";
					echo  'please only jpeg image is allowed';
					echo "</pre>";	
				}
			}
			else
			{
				echo "<pre>";
				echo  'please only jpeg image is allowed';
				echo "</pre>";
			}
			
		}
		else
		{
			echo "<pre>";
			echo  'please add a valid image';
			echo "</pre>";
		}

	}
?>
<html> 

	<head>
		
		<title>change profile image | Timeline</title>
	</head>
	<style>
	#bluebar{
			height: 50px;
			background-color:#405d9b;
			color: #d9dfdb;
			}
#searchbox{
	width:400px;
	height:20px;
	border-radius:5px;
	border:none;
	padding:4px;
	font-size:14px;
	background-image: url(search.png);
	background-repeat:no-repeat;
	background-position:right;
	}

	
#post_btn{
	float:right;
	background-color:blue;
	border:none;
	color:white;
	padding:4px;
	font-size:14px;
	border-radius:2px;
	/*width:50px; auto */ 
	}		
#post_bar{
	margin-top:20px;
	background-color:white;
	padding:10px;
	padding-top:20px;
	}	
#post{
	padding:4px;
	font-size:13px;
	display:flex;
	margin-bottom:20px;

	}
	</style>
	<body style="font-family:tahoma;background-color:#d0d8d4;">
		<!--top bar-->
		<?php include("header.php")?>
		<!--cover area-->
		<div style="width:800px; margin:auto; min-height:400px;">
			
		  <!--Below cover area-->
			<div style ="display:flex;">
				
				<!--friends area-->
				
				
				<!--post area-->
				<div style="min-height:400px; flex:2.5; padding:20px; padding-right:0px;">
					<form action="" method="post" enctype="multipart/form-data">
						<div style="border:solid thin #aaa; padding:10px;background-color:white;">
							<input type="file" name="file" id="">

							<input type="submit" id="post_btn"value="change">
							<br>
							<br>
						</div>
					</form>
							<!--post area-->
			
				</div>
		  </div>
		</div>
	</body>
	</html>