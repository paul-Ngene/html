<?php
    class Login
    {
        private $error = "";
    
        public function evaluate($data)
        {
            $email=addslashes($data['email']);
            $password=addslashes($data['password']);
    
            $query = "select * from users where email = '$email' limit 1 ";
    
           // return $query;
            echo $query;
    
            $DB= new Database();
           $result= $DB->read($query);
       
           if($result)
           {
                $row = $result[0];// $row is an array of rows
                if($password == $row['password'])
                {
                    //session data
                    $_SESSION['mybook_userid'] = $row['user_id'];
                }
                else
                {
                    $this->error .= "wrong password<br>";
                }
           }
           else
           {
               $this->error .= "No such email<br>";
           }
          
            return  $this->error;
    
        }
        
        public function check_login($id)
        {
            if(is_numeric($id))
            {
                $query = "select * from users where user_id = '$id' limit 1 ";// selects a single row from array of rows where $id is same as user_id 
                //$query = "select user_id from users where user_id = '$id' limit 1 "; 
                // selects only the user_id from a row in the array of rows where $id is same as user_id 
                $DB= new Database();
                $result= $DB->read($query); // result is an array of rows
                
                /*echo "<pre>";
                var_dump($result);
                echo "</pre>";*/

                if($result)
                {
                    $user_data = $result[0]; //returning the first row
                    return $user_data;
                }
                else
                {
                    header("Location: login.php");
                    die;
                }
                
            }
            else
            {
                header("Location: login.php");
                die;
            }
        }
    }
?>