<?php
    class user
    {
        public function get_data($id)
        {
            $query= "select * from users where user_id = '$id' limit 1";
            $Db = new Database();
            $result = $Db->read($query);// returns array of users

            if($result) 
            {
                $row = $result[0];
                return $row;
            }
            else
            {
                return false;
            }
        }

        public function get_user($id)
        {
            $query= "select * from users where user_id = '$id' limit 1";
            $Db = new Database();
            $result = $Db->read($query);
            if($result)
            {
                return $result[0];
            }
            else
            {
                return false;
            }
        }

        public function get_friends($id)
        {
            $query= "select * from users where user_id != '$id' ";
            $Db = new Database();
            $result = $Db->read($query);
            if($result)
            {
                return $result;
            }
            else
            {
                return false;
            }
        }
    }
?>