<?php


class Database
{
	private $host="localhost";
	private $username="root";
	private $password="";
	private $db="mybook_db";

	function connect()
	{
		$con = mysqli_connect($this->host,$this->username,$this->password,$this->db);
		return $con;
	}

	function read($query)
	{
		$conn = $this->connect();//this is used because its same class
		$result=mysqli_query($conn, $query);
		if(!$result)
		{
			return false;
		}
		else 
		{
			$data= false;
			while($row= mysqli_fetch_assoc($result))
			{
				$data[]= $row;
			}
			return $data;// data is an array of rows
		}
	}

	function save($query)
	{
		$conn = $this->connect();
		$result=mysqli_query($conn, $query);
		if(!$result)
		{
			return false;
		}
		else return true;
	}

}

/*
$DB=new Database();
$query ="select * from users";
$data= $DB->read($query);
echo "<pre>";
print_r($data);
echo "</pre>";
$first_name="paul";
$last_name="onyedika";

$query = "insert into users (first_name,last_Name) values ('$first_name','$last_name')";
$query ="select * from users";


while($row= mysqli_fetch_assoc($result))
{
	echo "<pre>";
	print_r($row);
	echo "</pre>"; 

}

echo mysqli_error($query);*/
?>
