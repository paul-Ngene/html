<div id="bluebar">
			<div style="width:800px;margin:auto;font-size:30px;">
				<a href="index.php" style="color:white;">Mybook</a>
				 &nbsp &nbsp
				<input id="searchbox" type="text" placeholder="search for people">
				<img src="selfie.jpg" style="width:50px;float:right;">
				<a href="logout.php">
					<span style=" font-size:11px; float:right; margin: 10px; color:white;">Logout</span>
				</a>
			</div>
		</div>